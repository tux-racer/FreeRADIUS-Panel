<?php
// index.php
session_start();
require_once 'config.php';
require_once 'RadiusModel.php';
require_once 'views.php';

$model = new RadiusModel();
$action = $_GET['action'] ?? '';

// 1. Handling Authentication (Login)
if (isset($_POST['login'])) {
    $passwordInput = $_POST['password'] ?? '';
    // Memeriksa hash password, aman dari inspect element karena teks mentah tidak disimpan di html/js
    if (password_verify($passwordInput, ADMIN_PASSWORD_HASH)) {
        $_SESSION['login'] = true;
        header("Location: index.php");
        exit;
    } else {
        renderLogin("Password salah!");
        exit;
    }
}

// 2. Handling Logout
if ($action === 'logout') {
    session_destroy();
    header("Location: index.php");
    exit;
}

// 3. Proteksi Session Halaman Utama
if (!isset($_SESSION['login']) || $_SESSION['login'] !== true) {
    renderLogin();
    exit;
}

// 4. Router Action untuk Fitur CRUD & Monitor (Hanya dieksekusi jika lolos login)
switch ($action) {
    case 'delete':
        if (isset($_GET['u'])) {
            $model->deleteUser($_GET['u']);
        }
        header("Location: index.php");
        exit;

    case 'kick':
        if (isset($_GET['session'])) {
            $model->kickUser($_GET['session']);
        }
        header("Location: index.php");
        exit;

    case 'save':
        if ($_SERVER['REQUEST_METHOD'] === 'POST') {
            $data = [
                'username'     => trim($_POST['username'] ?? ''),
                'password'     => trim($_POST['password'] ?? ''),
                'expire'       => trim($_POST['expire'] ?? ''),
                'simultaneous' => trim($_POST['simultaneous'] ?? ''),
                'timeout'      => trim($_POST['timeout'] ?? ''),
                'speed'        => trim($_POST['speed'] ?? '')
            ];
            if ($data['username'] !== '') {
                $model->saveUser($data);
            }
        }
        header("Location: index.php");
        exit;

    default:
        // Jika tidak ada action spesifik, tampilkan dashboard utama (Read)
        $active_users = $model->getActiveUsers();
        $users = $model->getUserList();
        renderDashboard($active_users, $users);
        break;
}