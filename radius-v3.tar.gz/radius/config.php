<?php
// config.php
define('DB_HOST', '10.10.0.15');
define('DB_NAME', 'radius');
define('DB_USER', 'user');
define('DB_PASS', 'passwd');

// Password Panel (Menggunakan password_hash untuk keamanan optimal)
// Hash ini bernilai 'admin123'. Jika ingin mengubah, gunakan: password_hash('password_baru', PASSWORD_BCRYPT);
define('ADMIN_PASSWORD_HASH', '$2y$10$M5fvkBG3GkMgbeUaW8.ydOUhrCsXbJNvUXm00y8Rr.Fasdasdefvs');

class Database {
    private static $instance = null;

    public static function getConnection() {
        if (self::$instance === null) {
            try {
                self::$instance = new PDO(
                    "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
                    DB_USER,
                    DB_PASS
                );
                self::$instance->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
                self::$instance->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            } catch (PDOException $e) {
                die("Database Connection Error: " . $e->getMessage());
            }
        }
        return self::$instance;
    }
}
