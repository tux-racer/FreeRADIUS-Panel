<?php
// views.php

function renderLogin($error = null) {
    ?>
    <!doctype html>
    <html lang="id">
    <head>
        <meta charset="utf-8">
        <title>FreeRadius - Login</title>
        <link href="css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-md-4 mt-5">
                    <div class="card shadow-sm">
                        <div class="card-header text-center bg-dark text-white">FreeRADIUS Panel</div>
                        <div class="card-body">
                            <?php if ($error): ?>
                                <div class='alert alert-danger py-2'><?= htmlspecialchars($error) ?></div>
                            <?php endif; ?>
                            <form method="post" action="index.php">
                                <!-- Input password kosong/bersih, nilainya tidak dilempar dari backend -->
                                <input type="password" name="password" class="form-control mb-3" placeholder="Admin Password" required autocomplete="off">
                                <button class="btn btn-primary w-100" name="login">Login</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
}

function renderDashboard($active_users, $users) {
    $total_active = count($active_users);
    ?>
    <!doctype html>
    <html lang="id">
    <head>
        <meta charset="utf-8">
        <title>FreeRADIUS Panel</title>
          <link href="css/bootstrap.min.css" rel="stylesheet">
    </head>
    <body class="bg-light">
    <nav class="navbar navbar-dark bg-dark">
        <div class="container-fluid">
            <span class="navbar-brand">FreeRADIUS Panel</span>
            <span class="badge bg-success me-auto ms-2">Online Clients: <?= $total_active ?></span>
            <a href="index.php?action=logout" class="btn btn-danger btn-sm">Logout</a>
        </div>
    </nav>

    <div class="container mt-4">
        <!-- FORM ADD / UPDATE -->
        <div class="card mb-4 shadow-sm">
            <div class="card-header bg-secondary text-white">Add / Update User</div>
            <div class="card-body">
                <form method="post" action="index.php?action=save" class="row g-2">
                    <div class="col-md-2"><input type="text" name="username" class="form-control" placeholder="Username" required></div>
                    <div class="col-md-2"><input type="text" name="password" class="form-control" placeholder="Password" required></div>
                    <div class="col-md-2"><input type="date" name="expire" class="form-control" title="Expire Date"></div>
                    <div class="col-md-2"><input type="number" name="simultaneous" class="form-control" placeholder="Device Use" min="1"></div>
                    <div class="col-md-2"><input type="text" name="timeout" class="form-control" placeholder="Durasi (sec)"></div>
                    <div class="col-md-2"><input type="text" name="speed" class="form-control" placeholder="Rate Limit (e.g. 10M/10M)"></div>
                    <div class="col-md-12 mt-3"><button class="btn btn-primary w-100">Save User</button></div>
                </form>
            </div>
        </div>

        <!-- MONITORING ACTIVE SESSIONS -->
        <div class="card mb-4 border-success shadow-sm">
            <div class="card-header bg-success text-white d-flex justify-content-between align-items-center">
                <span><strong>Active Sessions (Monitoring)</strong></span>
                <span class="badge bg-white text-success fw-bold"><?= $total_active ?> User Online</span>
            </div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-hover align-middle">
                    <thead class="table-light">
                        <tr>
                            <th>Username</th>
                            <th>NAS / Router IP</th>
                            <th>Client IP Address</th>
                            <th>Login Time</th>
                            <th>Uptime</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if ($total_active > 0): ?>
                        <?php foreach($active_users as $au): 
                            $hours = floor($au['duration'] / 3600);
                            $minutes = floor(($au['duration'] / 60) % 60);
                            $seconds = $au['duration'] % 60;
                            $uptime = sprintf("%02dh %02dm %02ds", $hours, $minutes, $seconds);
                        ?>
                            <tr>
                                <td><strong><?= htmlspecialchars($au['username']) ?></strong></td>
                                <td><?= htmlspecialchars($au['nasipaddress']) ?></td>
                                <td><span class="badge bg-info text-dark"><?= htmlspecialchars($au['framedipaddress'] ?? 'N/A') ?></span></td>
                                <td><?= htmlspecialchars($au['acctstarttime']) ?></td>
                                <td><?= $uptime ?></td>
                                <td>
                                    <a href="index.php?action=kick&session=<?= $au['radacctid'] ?>" class="btn btn-sm btn-warning" onclick="return confirm('Kick user ini?')">Kick</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center text-muted py-3">Tidak ada client yang aktif saat ini.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- USER LIST -->
        <div class="card shadow-sm">
            <div class="card-header bg-dark text-white">User List</div>
            <div class="card-body table-responsive">
                <table class="table table-bordered table-striped align-middle">
                    <thead class="table-dark">
                        <tr>
                            <th>Username</th>
                            <th>Expire</th>
                            <th>Device</th>
                            <th>Durasi</th>
                            <th>Rate Limit</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (count($users) > 0): ?>
                        <?php foreach($users as $u): ?>
                            <tr>
                                <td><?= htmlspecialchars($u['username']) ?></td>
                                <td><?= htmlspecialchars($u['expire'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($u['simultaneous'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($u['timeout'] ?? '-') ?></td>
                                <td><?= htmlspecialchars($u['speed'] ?? '-') ?></td>
                                <td>
                                    <a href="index.php?action=delete&u=<?= urlencode($u['username']) ?>" class="btn btn-sm btn-danger" onclick="return confirm('Hapus user ini?')">Delete</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    <?php else: ?>
                        <tr><td colspan="6" class="text-center text-muted">Belum ada data user.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    </body>
    </html>
    <?php
}