<?php
// clean_radius.php
if (php_sapi_name() !== 'cli') {
    die("Script ini hanya dapat dijalankan melalui terminal (CLI).\n");
}

require_once __DIR__ . '/config.php';

try {
    $db = Database::getConnection();
    echo "[" . date('Y-m-d H:i:s') . "] Memulai proses pembersihan database RADIUS...\n";

    // 1. Hapus User yang Tanggal Expiration-nya Sudah Lewat
    $sqlExpired = "
        SELECT DISTINCT username 
        FROM radcheck 
        WHERE attribute = 'Expiration' 
          AND STR_TO_DATE(value, '%d %b %Y %H:%i:%s') < NOW()
    ";
    $expiredUsers = $db->query($sqlExpired)->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($expiredUsers)) {
        $inClause = implode(',', array_fill(0, count($expiredUsers), '?'));
        
        // Hapus dari radcheck, radreply, radusergroup, dan radacct
        $db->prepare("DELETE FROM radcheck WHERE username IN ($inClause)")->execute($expiredUsers);
        $db->prepare("DELETE FROM radreply WHERE username IN ($inClause)")->execute($expiredUsers);
        $db->prepare("DELETE FROM radusergroup WHERE username IN ($inClause)")->execute($expiredUsers);
        $db->prepare("DELETE FROM radacct WHERE username IN ($inClause)")->execute($expiredUsers);

        echo "- Berhasil menghapus " . count($expiredUsers) . " user yang sudah Expire.\n";
    } else {
        echo "- Tidak ada user expired yang perlu dihapus.\n";
    }

    // 2. Hapus User yang Tidak Pernah Login Sama Sekali (Orphan Users)
    // Kriteria: Ada di radcheck, tetapi tidak pernah tercatat di radacct
    $sqlUnused = "
        SELECT DISTINCT c.username 
        FROM radcheck c
        LEFT JOIN radacct a ON c.username = a.username
        WHERE a.username IS NULL
    ";
    $unusedUsers = $db->query($sqlUnused)->fetchAll(PDO::FETCH_COLUMN);

    if (!empty($unusedUsers)) {
        $inClause = implode(',', array_fill(0, count($unusedUsers), '?'));

        $db->prepare("DELETE FROM radcheck WHERE username IN ($inClause)")->execute($unusedUsers);
        $db->prepare("DELETE FROM radreply WHERE username IN ($inClause)")->execute($unusedUsers);
        $db->prepare("DELETE FROM radusergroup WHERE username IN ($inClause)")->execute($unusedUsers);

        echo "- Berhasil menghapus " . count($unusedUsers) . " user yang tidak pernah login.\n";
    } else {
        echo "- Tidak ada user tanpa riwayat login.\n";
    }

    // 3. Bersihkan Log Post-Auth & Log Session Lama (Opsional: Bersihkan log > 30 hari)
    $stmt1 = $db->prepare("DELETE FROM radpostauth WHERE authdate < NOW() - INTERVAL 30 DAY");
    $stmt1->execute();
    echo "- Log radpostauth di atas 30 hari berhasil dibersihkan (" . $stmt1->rowCount() . " baris).\n";

    // 4. Optimization & Defragmentation Tabel Database
    $tables = ['radcheck', 'radreply', 'radusergroup', 'radacct', 'radpostauth'];
    foreach ($tables as $table) {
        $db->query("OPTIMIZE TABLE $table");
    }
    echo "- Optimalisasi & defragmentasi tabel selesai.\n";

    echo "[" . date('Y-m-d H:i:s') . "] Pembersihan database selesai dengan sukses!\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}