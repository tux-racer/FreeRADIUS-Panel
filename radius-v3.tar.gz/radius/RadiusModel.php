<?php
// RadiusModel.php
require_once 'config.php';

class RadiusModel {
    private $db;

    public function __construct() {
        $this->db = Database::getConnection();
        // Hapus user yang TANGGAL EXPIRE-nya sudah lewat
        $this->cleanupExpiredUsers();
    }

    public function deleteUser($username) {
    $stmt1 = $this->db->prepare("DELETE FROM radcheck WHERE username = ?");
    $stmt1->execute([$username]);
    
    $stmt2 = $this->db->prepare("DELETE FROM radreply WHERE username = ?");
    $stmt2->execute([$username]);

    // Hapus juga riwayat accounting agar kuota harian ter-reset bersih
    $stmt3 = $this->db->prepare("DELETE FROM radacct WHERE username = ?");
    $stmt3->execute([$username]);
}
    // fungsi kickuser
    public function kickUser($sessionId) {
    // 1. Ambil data session aktif dari MariaDB (10.10.0.15)
    $stmtSelect = $this->db->prepare("
        SELECT username, nasipaddress, acctsessionid, framedipaddress 
        FROM radacct 
        WHERE radacctid = ? AND acctstoptime IS NULL
    ");
    $stmtSelect->execute([$sessionId]);
    $session = $stmtSelect->fetch();

    if ($session) {
        $username = $session['username'];
        $nasIp = $session['nasipaddress']; // IP MikroTik (10.10.0.1)
        $acctSessionId = $session['acctsessionid'];
        $framedIp = $session['framedipaddress'] ?? '';
        $secret = 'radius-passwd'; // Sesuaikan dengan Secret Key RADIUS di MikroTik Anda

        // 2. Susun atribut RADIUS Disconnect
        $attributes = [];
        $attributes[] = "User-Name={$username}";
        if (!empty($acctSessionId)) {
            $attributes[] = "Acct-Session-Id={$acctSessionId}";
        }
        if (!empty($framedIp) && $framedIp !== 'N/A') {
            $attributes[] = "Framed-IP-Address={$framedIp}";
        }

        $payload = implode("\n", $attributes);

        // 3. Eksekusi radclient di VM 10.10.0.15 via SSH menggunakan SSH Key www-data
        $remoteCmd = "printf " . escapeshellarg($payload) . " | /usr/bin/radclient -x {$nasIp}:3799 disconnect {$secret}";
        $cmd = "ssh -i /var/www/.ssh/id_rsa -o StrictHostKeyChecking=no billy@10.10.0.15 " . escapeshellarg($remoteCmd) . " 2>&1";

        exec($cmd, $output, $returnCode);

        // 4. Update status session di database radacct
        $stmtUpdate = $this->db->prepare("
            UPDATE radacct 
            SET acctstoptime = NOW(), acctterminatecause = 'Admin Reset' 
            WHERE radacctid = ?
        ");
        $stmtUpdate->execute([$sessionId]);
    }
}

    // Di dalam file RadiusModel.php

public function saveUser($data) {
    // Hapus data lama agar tidak duplikat saat update
    $this->deleteUser($data['username']);

    // Insert password wajib
    $stmt = $this->db->prepare("INSERT INTO radcheck (username, attribute, op, value) VALUES (?, 'Cleartext-Password', ':=', ?)");
    $stmt->execute([$data['username'], $data['password']]);

    // 1. Simpan Tanggal Expire dengan jam hingga akhir hari (23:59:59)
    if (!empty($data['expire'])) {
        // Format standar FreeRADIUS yang paling kompatibel: "11 Sep 2026 23:59:59"
        $formattedExpire = date("d M Y 23:59:59", strtotime($data['expire']));
        $stmt = $this->db->prepare("INSERT INTO radcheck (username, attribute, op, value) VALUES (?, 'Expiration', ':=', ?)");
        $stmt->execute([$data['username'], $formattedExpire]);
    }

    if (!empty($data['simultaneous'])) {
        $stmt = $this->db->prepare("INSERT INTO radcheck (username, attribute, op, value) VALUES (?, 'Simultaneous-Use', ':=', ?)");
        $stmt->execute([$data['username'], $data['simultaneous']]);
    }

    if (!empty($data['timeout'])) {
        $stmt = $this->db->prepare("INSERT INTO radcheck (username, attribute, op, value) VALUES (?, 'Max-Daily-Session', ':=', ?)");
        $stmt->execute([$data['username'], $data['timeout']]);

        $stmt = $this->db->prepare("INSERT INTO radreply (username, attribute, op, value) VALUES (?, 'Session-Timeout', ':=', ?)");
        $stmt->execute([$data['username'], $data['timeout']]);
    }

    if (!empty($data['speed'])) {
        $stmt = $this->db->prepare("INSERT INTO radreply (username, attribute, op, value) VALUES (?, 'Mikrotik-Rate-Limit', ':=', ?)");
        $stmt->execute([$data['username'], $data['speed']]);
    }
}

    /**
     * Hapus akun HANYA jika tanggal Expiration sudah terlewati.
     * Menggunakan format tanggal standar FreeRADIUS ('d M Y' -> contoh: '11 Sep 2026')
     */
    public function cleanupExpiredUsers() {
        $sql = "SELECT username, value FROM radcheck WHERE attribute = 'Expiration'";
        $records = $this->db->query($sql)->fetchAll();

        $today = strtotime('today'); // Jam 00:00:00 hari ini

        foreach ($records as $row) {
            $expireDate = strtotime($row['value']);
            // Jika tanggal expire sudah berlalu (misal expire 11 Sep, sekarang 12 Sep)
            if ($expireDate && $expireDate < $today) {
                $this->deleteUser($row['username']);
            }
        }
    }

    public function getUserList() {
        $sql = "
            SELECT 
                c.username,
                MAX(CASE WHEN c.attribute='Expiration' THEN c.value END) as expire,
                MAX(CASE WHEN c.attribute='Simultaneous-Use' THEN c.value END) as simultaneous,
                MAX(CASE WHEN r.attribute='Session-Timeout' THEN r.value END) as timeout,
                MAX(CASE WHEN r.attribute='Mikrotik-Rate-Limit' THEN r.value END) as speed
            FROM radcheck c
            LEFT JOIN radreply r ON c.username = r.username
            GROUP BY c.username
            ORDER BY c.username
        ";
        return $this->db->query($sql)->fetchAll();
    }

    public function getActiveUsers() {
        $sql = "
            SELECT 
                radacctid,
                username, 
                nasipaddress, 
                framedipaddress, 
                acctstarttime, 
                nasportid,
                (UNIX_TIMESTAMP(NOW()) - UNIX_TIMESTAMP(acctstarttime)) AS duration
            FROM radacct 
            WHERE acctstoptime IS NULL
            ORDER BY acctstarttime DESC
        ";
        return $this->db->query($sql)->fetchAll();
    }
}
